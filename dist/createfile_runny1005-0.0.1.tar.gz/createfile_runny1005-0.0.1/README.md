# This is just a project that i made so i can use csv and json with auto file creation
yeah that's it